-- phpMyAdmin SQL Dump
-- version 4.7.8
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 26, 2018 at 03:08 PM
-- Server version: 5.7.18-log
-- PHP Version: 7.1.4RC1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `betacode_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `graphics`
--

CREATE TABLE `graphics` (
  `id` int(11) NOT NULL,
  `filename` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `graphics`
--

INSERT INTO `graphics` (`id`, `filename`) VALUES
(1, '\"Littlefield-Graphic-Art.png\"'),
(2, '\"city_night_colored_halation_background_vector_graphics_543464.jpg\"'),
(3, '\"art and graphic art.png\"');

-- --------------------------------------------------------

--
-- Table structure for table `qa_easy_history`
--

CREATE TABLE `qa_easy_history` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `difficulty` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `qa_easy_history`
--

INSERT INTO `qa_easy_history` (`id`, `question`, `answer`, `difficulty`) VALUES
(1, 'Who is Theodora', 'Powerful political figure. Actress before meeting Justinian', 'easy'),
(2, 'fire', 'ice', 'Easy'),
(3, 'Who was the first President?', 'George Washington', 'Easy');

-- --------------------------------------------------------

--
-- Table structure for table `qa_easy_math`
--

CREATE TABLE `qa_easy_math` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `difficulty` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `qa_easy_math`
--

INSERT INTO `qa_easy_math` (`id`, `question`, `answer`, `difficulty`) VALUES
(1, 'What is 2+2', '4', 'easy');

-- --------------------------------------------------------

--
-- Table structure for table `qa_easy_science`
--

CREATE TABLE `qa_easy_science` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `difficulty` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `qa_easy_science`
--

INSERT INTO `qa_easy_science` (`id`, `question`, `answer`, `difficulty`) VALUES
(1, 'Why is the sky blue? ', 'Air particle reflect blue light and absorb red light ', 'easy'),
(2, 'fire', 'ice', 'Easy'),
(3, 'fire', 'ice', 'Easy'),
(4, 'fire', 'ice', 'Easy'),
(5, 'fire', 'ice', 'Easy'),
(6, 'fire', 'ice', 'Easy'),
(7, 'fire', 'ice', 'Easy'),
(8, 'fire', 'ice', 'Easy'),
(9, 'fire', 'ice', 'Easy'),
(10, 'fire', 'ice', 'Easy'),
(11, 'fire', 'ice', 'Easy');

-- --------------------------------------------------------

--
-- Table structure for table `qa_hard_history`
--

CREATE TABLE `qa_hard_history` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `difficulty` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `qa_hard_history`
--

INSERT INTO `qa_hard_history` (`id`, `question`, `answer`, `difficulty`) VALUES
(1, '[insert history question]', '[insert history answer]', 'Hard');

-- --------------------------------------------------------

--
-- Table structure for table `qa_hard_math`
--

CREATE TABLE `qa_hard_math` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `difficulty` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `qa_hard_math`
--

INSERT INTO `qa_hard_math` (`id`, `question`, `answer`, `difficulty`) VALUES
(1, 'Use the gauss geogden elimination to solve the following matrix. \r\n<img src=\"https://cdn.kastatic.org/ka-exercise-screenshots/matrix_determinant_3x3.png\">', '.........', 'Hard');

-- --------------------------------------------------------

--
-- Table structure for table `qa_hard_science`
--

CREATE TABLE `qa_hard_science` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `difficulty` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `qa_hard_science`
--

INSERT INTO `qa_hard_science` (`id`, `question`, `answer`, `difficulty`) VALUES
(1, 'Name 1 difference between Eukaryotic cells and Prokaryotic cells', 'Eukaryotic cells have membrane bound nucleolus. Prokaryotic cells neclelus floats in the cytoplasm as a long strand. ', 'hard'),
(2, 'g', 'g', 'Hard'),
(3, 'g', 'g', 'Hard'),
(4, 'g', 'g', 'Hard'),
(5, 'g', 'g', 'Hard'),
(6, 'g', 'g', 'Hard');

-- --------------------------------------------------------

--
-- Table structure for table `qa_medium_history`
--

CREATE TABLE `qa_medium_history` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `difficulty` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `qa_medium_history`
--

INSERT INTO `qa_medium_history` (`id`, `question`, `answer`, `difficulty`) VALUES
(1, '[insert history question]', '[insert history answer]', 'medium');

-- --------------------------------------------------------

--
-- Table structure for table `qa_medium_math`
--

CREATE TABLE `qa_medium_math` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `difficulty` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `qa_medium_math`
--

INSERT INTO `qa_medium_math` (`id`, `question`, `answer`, `difficulty`) VALUES
(1, 'What is a variable?', 'A variable is the concept of a container that represent a value. ', 'medium');

-- --------------------------------------------------------

--
-- Table structure for table `qa_medium_science`
--

CREATE TABLE `qa_medium_science` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `difficulty` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `qa_medium_science`
--

INSERT INTO `qa_medium_science` (`id`, `question`, `answer`, `difficulty`) VALUES
(1, 'What are the different types of coral reefs?', 'Fringing reefs, barrier reefs, patch reefs and atolls', 'medium'),
(2, 'a', 'a', 'Medium');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `title` varchar(10) NOT NULL,
  `admin` tinyint(1) NOT NULL,
  `course` varchar(15) NOT NULL,
  `avatar` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `username`, `password`, `email`, `title`, `admin`, `course`, `avatar`) VALUES
(1, 'guccie ', 'mane', 'G. mane', 'wrap', 'gucciemane@worldstar.com', 'teacher', 0, 'rap', ''),
(2, 'chris', 'dell', 'laurent', 'star', 'l@udc.edu', 'admin', 1, 'admin', ''),
(3, 'mickey', 'mouse', 'disney', 'star', 'dis@gmail.com', 'student', 0, 'NULL', ''),
(4, 'Nicky', 'Menaje', 'crazy', 'n123', 'nicky.menaje@gmail.com', 'student', 0, 'NULL', ''),
(5, 'O', 'a', 'b', 'c', 'd', 'e', 0, 'g', 'h'),
(12, 'O', 'oo', 'ooo', 'oooo', 'ooooo', 'Student', 0, 'Math', 'o'),
(13, '', '', '', '', '', '', 0, '', 'o'),
(14, 'a', 'aa', 'aaa', 'aaaa', 'aaaaa', 'Student', 0, 'Math', 'o'),
(15, 'a', 'aa', 'aaa', 'aaaa', 'aaaaa', 'Student', 0, 'Math', 'o'),
(16, 'a', 'aa', 'aaa', 'aaaa', 'aaaaa', 'Student', 0, 'Math', 'o'),
(17, 'a', 'aa', 'aaa', 'aaaa', 'aaaaa', 'Student', 0, 'Math', 'o'),
(18, 'a', 'aa', 'aaa', 'aaaa', 'aaaaa', 'Student', 0, 'Math', 'o'),
(19, 'a', 'b', 'ab', 'hive', 'ab@gmail.com', 'Teacher', 0, 'Math', 'o');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `graphics`
--
ALTER TABLE `graphics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qa_easy_history`
--
ALTER TABLE `qa_easy_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qa_easy_math`
--
ALTER TABLE `qa_easy_math`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qa_easy_science`
--
ALTER TABLE `qa_easy_science`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qa_hard_history`
--
ALTER TABLE `qa_hard_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qa_hard_math`
--
ALTER TABLE `qa_hard_math`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qa_hard_science`
--
ALTER TABLE `qa_hard_science`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qa_medium_history`
--
ALTER TABLE `qa_medium_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qa_medium_math`
--
ALTER TABLE `qa_medium_math`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qa_medium_science`
--
ALTER TABLE `qa_medium_science`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `graphics`
--
ALTER TABLE `graphics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `qa_easy_history`
--
ALTER TABLE `qa_easy_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `qa_easy_math`
--
ALTER TABLE `qa_easy_math`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `qa_easy_science`
--
ALTER TABLE `qa_easy_science`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `qa_hard_history`
--
ALTER TABLE `qa_hard_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `qa_hard_math`
--
ALTER TABLE `qa_hard_math`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `qa_hard_science`
--
ALTER TABLE `qa_hard_science`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `qa_medium_history`
--
ALTER TABLE `qa_medium_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `qa_medium_math`
--
ALTER TABLE `qa_medium_math`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `qa_medium_science`
--
ALTER TABLE `qa_medium_science`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
