<!DOCTYPE html>
<html>
<head>
		<!-- Page Created by:  Christian Mundell
		<!--///////////////////////////////////////
		//				TEAM 1					 //
		////////////////////////////////////////-->
<title>Verifies login request</title>
<link rel="stylesheet" href="Demo.css">
</head>
	<body>
		<!-- Login Model-->
		<div  class=" w3-top w-left">
			<img src="Black_Light.png" alt="Avatar"  style="max-width:70px;">	
		</div>
		<div class=" w3-margin-top w3-center">				
			<h1 style="font-size: 2em; letter-spacing: 1em; background-color: white;">YOUSHOULDSTUDY.COM</h1>
		</div>				
		<div class="container" id="top" style="background-color: red;">
			<div class="w3-bar  w3-red w3-opacity-min w3-wide  w3-card-2">

			</div>
		</div>
		<div class=" w3-margin-top w3-center">
			<h2 style="font-size: 2em; letter-spacing: 1em; background-color: white;">LOGIN VERIFICATION PAGE</h2>
		</div>
		
		<br>	<br>	<br>	<br>	
		<div class=" w3-center">
			<h1>Please wait to be redirected to the appropriate page</h1>
		</div>

		<?php
			// starting the session
			session_start(); 
			$servername = "localhost";
			$username = "root";
			$password = "TheMango0*";
			$database = "betacode_database";

			//Testing search terms
			$testUsername = $_POST['uname'];
			$testPassword = $_POST['psw'];
			$testTitle;
			$testTable = "users";
			$pagelocation = "LoginPage.php";
			
			// Create connection
			$conn = new mysqli($servername, $username, $password, $database);

		
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			} 
			
			
			$query = "	SELECT id, firstname, lastname, username, password, email, title, course, avatar
						FROM $testTable 
						WHERE username = '$testUsername' AND password = '$testPassword'";

			

			$result=mysqli_query($conn,$query);
			
			
				if ($result->num_rows > 0) 
				{
			
					$row = mysqli_fetch_assoc($result);
						
					
						switch ($row["title"])
						{
							case "admin":	$pagelocation = "StudentProfile.php"; 
											//Send the user to the admin page
											echo "Sending you to  admin settings page now. ";	
							break;
							case "teacher": $pagelocation = "StudentProfile.php";
											//Send the user to the admin page
											echo "Sending you to  teacher settings page now. ";	
							break;
							case "student": 	$pagelocation = "StudentProfile.php";
											echo "Sending you to  your personalize page now page now ";	
							break;
						}
					//	Set the session variables to maintain the user login
					$_SESSION['id'] = $row["id"];
					$_SESSION['firstname'] = $row["firstname"];
					$_SESSION['lastname'] = $row["lastname"];
					$_SESSION['username'] = $row["username"];
					$_SESSION['email'] = $row["email"];
					$_SESSION['title'] = $row["title"];
					$_SESSION['avatar'] = $row["avatar"];
					$_SESSION['course'] = $row["course"];					
				}
			else 
			{
				echo"I'm sorry, your user & password does not exist. Please go away......";
				$pagelocation = "LoginPage.php";
			}
			
	
			
			
			mysqli_free_result($result);
			mysqli_close($conn);
		?>
		
		<!--Send the user where they suppose to go-->
		<a href=></a>
		<meta http-equiv="Refresh" content="5;url=<?php echo $pagelocation; ?>">
		<p class="w3-center"> <img src="groupfooterfinal.png"></p>
	
	</body>
</html>