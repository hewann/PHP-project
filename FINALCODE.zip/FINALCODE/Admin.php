<!DOCTYPE html>
<html>

	<head>  
		<!-- Page Created by:  Eaan Whiteside
		<!--///////////////////////////////////////
		//				TEAM 1					 //
		////////////////////////////////////////-->
		<meta charset="UTF-8" />
		<title>YouShouldStudy.com - Login</title>
		<script src="modernizr-1.5.js"></script>

		<link rel="stylesheet" href="Demo.css">	


		<style type="text/css">
			..login {
				padding: 6px;
				 margin: 25px 50px 0px 115px;
				 width: 94%;
			}

			.boxes {
				padding: 0px;
				 margin: 0px 0px 0px 20px;
			}


			input[type=text], input[type=password] {
				width: 40%;
				padding: 12px 20px;
				margin: 0px 0px;
				
				border: 1px solid #ccc;
				box-sizing: border-box;
			}

			input[type=submit] {
				background-color: #4CAF50;
				color: white;
				padding: 10px 0px;
				margin: 20px 81px;
				border: none;
				cursor: pointer;
				width: 70%;
			}
			.center {
			   
			   margin: 65px 0px 0px 200px;
			}

			select{
				width: 40%;
				margin: 15px 0px 0px 0px;
				border: 0.3px solid gray;
				height: 50px;
				background-color: white;
				color: black;
			}

			.option{
				width: 25%;
				margin: 15px 300px 0px 400px;
				border: 4px solid gray;
				height: 50px;
				background-color: red;
				color: white;
			}

			table, td, th {
				border: 0.5px solid black;
			}

			table {
				border-collapse: collapse;
				width: 80%;
				 margin: 25px 50px 0px 100px;
			}

			th {
				height: 38px;
			}

			td {
				height: 20px;
			}

			h3{
				margin: 40px 0px -27px -20px;
			}

			tr:nth-child(even) {background-color: #f2f2f2;}
		</style>
	</head>
	<body>
		<!-- Login Model-->
		<div  class=" w3-top w-left">
			<img src="Eaan_Whiteside_light.png" alt="Avatar" style="max-width:90px;">
		</div>
		<?php
			require('Header.php');
		?>
		<div class=" w3-margin-top w3-center">
			<h2 style="font-size: 2em; letter-spacing: 1em; background-color: white;">ADMIN SETTINGS PAGE</h2>
		</div>
      
	  
		<!-- Question and Answers Model-->
		<form action="insert.php" method="post"> 
			<div class=" w3-center">
			<div class="Eean_boxes w3-center ">
				<!-- <label for="uname"><b>Username</b></label> -->
				<input type="text" placeholder="Enter Question" name="Question" id="question">
				<input type="text" placeholder="Enter Answer" name="Answer" id="answer">
				</br>
				
				<select name="Topic">
					<option value="Science">Science</option>
					<option value="History">History</option>
					<option value="Math" >Math</option>
					<option value="Null" selected>Select Course</option>
				</select>
				<select name="Difficulty">
					<option value="Hard">Hard</option>
					<option value="Medium">Medium</option>
					<option value="Easy">Easy</option>
					<option value="SelectDifficulty" selected>Select Question Difficulty</option>
				</select>
				<input type="submit" value="Submit">	
			</div>
		</form>
		
		<!--------------------------
		QUESTION AND ANSWER MATH ---
		---------------------------->
		<h1>MATH EASY</h1>
		<?php
			$mysqli = new mysqli("localhost", "root", "TheMango0*", "betacode_database");
			$sql = "SELECT question, answer, difficulty FROM qa_easy_math";
			$result = $mysqli->query($sql);
			   			
			if($result = $mysqli->query($sql)){
				if($result->num_rows > 0){
					echo "<table bgcolor='#A0EEFE' border='0'align='center' style='margin: 0px auto'; >";
						echo "<tr>";
							echo "<th>Question</th>";
							echo "<th>Answer</th>";
							echo "<th>Difficulty</th>";
						echo "</tr>";
					while($row = $result->fetch_array()){
						echo "<tr>";
							echo "<td>" . $row['question'] . "</td>";
							echo "<td>" . $row['answer'] . "</td>";
							echo "<td>" . $row['difficulty'] . "</td>";
						echo "</tr>";
					}
					echo "</table>";   
				} 
			} 
		?>	

		<h1>MATH MEDIUM</h1>
		<?php
			$mysqli = new mysqli("localhost", "root", "TheMango0*", "betacode_database");
			$sql = "SELECT question, answer, difficulty FROM qa_medium_math";
			$result = $mysqli->query($sql);
			   			
			if($result = $mysqli->query($sql)){
				if($result->num_rows > 0){
					echo "<table bgcolor='#FFDC4B' border='0'align='center' style='margin: 0px auto'; >";
						echo "<tr>";
							echo "<th>Question</th>";
							echo "<th>Answer</th>";
							echo "<th>Difficulty</th>";
						echo "</tr>";
					while($row = $result->fetch_array()){
						echo "<tr>";
							echo "<td>" . $row['question'] . "</td>";
							echo "<td>" . $row['answer'] . "</td>";
							echo "<td>" . $row['difficulty'] . "</td>";
						echo "</tr>";
					}
					echo "</table>";   
				} 
			} 
		?>	
		<h1>MATH HARD</h1>
		<?php
			$mysqli = new mysqli("localhost", "root", "TheMango0*", "betacode_database");
			$sql = "SELECT question, answer, difficulty FROM qa_medium_math";
			$result = $mysqli->query($sql);
			   			
			if($result = $mysqli->query($sql)){
				if($result->num_rows > 0){
					echo "<table bgcolor='#FF4B4B' border='0'align='center' style='margin: 0px auto'; >";
						echo "<tr>";
							echo "<th>Question</th>";
							echo "<th>Answer</th>";
							echo "<th>Difficulty</th>";
						echo "</tr>";
					while($row = $result->fetch_array()){
						echo "<tr>";
							echo "<td>" . $row['question'] . "</td>";
							echo "<td>" . $row['answer'] . "</td>";
							echo "<td>" . $row['difficulty'] . "</td>";
						echo "</tr>";
					}
					echo "</table>";   
				} 
			} 
		?>	
		<!----------------------------
		QUESTION AND ANSWER SCIENCE---
		------------------------------>
		<h1>SCIENCE EASY</h1>
		<?php
			$mysqli = new mysqli("localhost", "root", "TheMango0*", "betacode_database");
			$sql = "SELECT question, answer, difficulty FROM qa_easy_science";
			$result = $mysqli->query($sql);
			   			
			if($result = $mysqli->query($sql)){
				if($result->num_rows > 0){
					echo "<table bgcolor='#A0EEFE' border='0'align='center' style='margin: 0px auto'; >";
						echo "<tr>";
							echo "<th>Question</th>";
							echo "<th>Answer</th>";
							echo "<th>Difficulty</th>";
						echo "</tr>";
					while($row = $result->fetch_array()){
						echo "<tr>";
							echo "<td>" . $row['question'] . "</td>";
							echo "<td>" . $row['answer'] . "</td>";
							echo "<td>" . $row['difficulty'] . "</td>";
						echo "</tr>";
					}
					echo "</table>";   
				} 
			} 
		?>	

		<h1>SCIENCE MEDIUM</h1>
		<?php
			$mysqli = new mysqli("localhost", "root", "TheMango0*", "betacode_database");
			$sql = "SELECT question, answer, difficulty FROM qa_medium_science";
			$result = $mysqli->query($sql);
			   			
			if($result = $mysqli->query($sql)){
				if($result->num_rows > 0){
					echo "<table bgcolor='#FFDC4B' border='0'align='center' style='margin: 0px auto'; >";
						echo "<tr>";
							echo "<th>Question</th>";
							echo "<th>Answer</th>";
							echo "<th>Difficulty</th>";
						echo "</tr>";
					while($row = $result->fetch_array()){
						echo "<tr>";
							echo "<td>" . $row['question'] . "</td>";
							echo "<td>" . $row['answer'] . "</td>";
							echo "<td>" . $row['difficulty'] . "</td>";
						echo "</tr>";
					}
					echo "</table>";   
				} 
			} 
		?>	
		<h1>SCIENCE HARD</h1>
		<?php
			$mysqli = new mysqli("localhost", "root", "TheMango0*", "betacode_database");
			$sql = "SELECT question, answer, difficulty FROM qa_hard_science";
			$result = $mysqli->query($sql);
			   			
			if($result = $mysqli->query($sql)){
				if($result->num_rows > 0){
					echo "<table bgcolor='#FF4B4B' border='0'align='center' style='margin: 0px auto'; >";
						echo "<tr>";
							echo "<th>Question</th>";
							echo "<th>Answer</th>";
							echo "<th>Difficulty</th>";
						echo "</tr>";
					while($row = $result->fetch_array()){
						echo "<tr>";
							echo "<td>" . $row['question'] . "</td>";
							echo "<td>" . $row['answer'] . "</td>";
							echo "<td>" . $row['difficulty'] . "</td>";
						echo "</tr>";
					}
					echo "</table>";   
				} 
			} 
		?>	
		<!----------------------------
		QUESTION AND ANSWER HISTORY --
		------------------------------>
		<h1>HISTORY EASY</h1>
		<?php
			$mysqli = new mysqli("localhost", "root", "TheMango0*", "betacode_database");
			$sql = "SELECT question, answer, difficulty FROM qa_easy_history";
			$result = $mysqli->query($sql);
			   			
			if($result = $mysqli->query($sql)){
				if($result->num_rows > 0){
					echo "<table bgcolor='#A0EEFE' border='0'align='center' style='margin: 0px auto'; >";
						echo "<tr>";
							echo "<th>Question</th>";
							echo "<th>Answer</th>";
							echo "<th>Difficulty</th>";
						echo "</tr>";
					while($row = $result->fetch_array()){
						echo "<tr>";
							echo "<td>" . $row['question'] . "</td>";
							echo "<td>" . $row['answer'] . "</td>";
							echo "<td>" . $row['difficulty'] . "</td>";
						echo "</tr>";
					}
					echo "</table>";   
				} 
			} 
		?>	

		<h1>HISTORY MEDIUM</h1>
		<?php
			$mysqli = new mysqli("localhost", "root", "TheMango0*", "betacode_database");
			$sql = "SELECT question, answer, difficulty FROM qa_medium_history";
			$result = $mysqli->query($sql);
			   			
			if($result = $mysqli->query($sql)){
				if($result->num_rows > 0){
					echo "<table bgcolor='#FFDC4B' border='0'align='center' style='margin: 0px auto'; >";
						echo "<tr>";
							echo "<th>Question</th>";
							echo "<th>Answer</th>";
							echo "<th>Difficulty</th>";
						echo "</tr>";
					while($row = $result->fetch_array()){
						echo "<tr>";
							echo "<td>" . $row['question'] . "</td>";
							echo "<td>" . $row['answer'] . "</td>";
							echo "<td>" . $row['difficulty'] . "</td>";
						echo "</tr>";
					}
					echo "</table>";   
				} 
			} 
		?>	
		<h1>HISTORY HARD</h1>
		<?php
			$mysqli = new mysqli("localhost", "root", "TheMango0*", "betacode_database");
			$sql = "SELECT question, answer, difficulty FROM qa_medium_history";
			$result = $mysqli->query($sql);
			   			
			if($result = $mysqli->query($sql)){
				if($result->num_rows > 0){
					echo "<table bgcolor='#FF4B4B' border='0'align='center' style='margin: 0px auto'; >";
						echo "<tr>";
							echo "<th>Question</th>";
							echo "<th>Answer</th>";
							echo "<th>Difficulty</th>";
						echo "</tr>";
					while($row = $result->fetch_array()){
						echo "<tr>";
							echo "<td>" . $row['question'] . "</td>";
							echo "<td>" . $row['answer'] . "</td>";
							echo "<td>" . $row['difficulty'] . "</td>";
						echo "</tr>";
					}
					echo "</table>";   
				} 
			} 
		?>	
		<p> <img src="groupfooterfinal.png"  class="w3-center"></p>

	</body>
</html>