
<html>
	<head>
		<!-- Page Created by:  Eaan Whiteside
		<!--///////////////////////////////////////
		//				TEAM 1					 //
		////////////////////////////////////////-->	
		
		<!-- Group Final Beta Code -->
		<title>YouShouldStudy.com - Home</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="Demo.css">


		<meta charset="UTF-8" />
		<title>YouShouldStudy.com - Login</title>
		<script src="modernizr-1.5.js"></script>
	</head>

	<body>
		<!-- Login Model-->
		<div  class=" w3-top w-left">	
			<img src="Eaan_Whiteside_light.png" alt="Avatar" style="max-width:90px;">
		</div>
		<?php
			require('Header.php');
		?>
		<div class=" w3-margin-top w3-center">
			<h2 style="font-size: 2em; letter-spacing: 1em; background-color: white;">STUDENT PROFILE</h2>
		</div>	
		

		<?php
			// starting the session
			session_start(); 
			$Id = $_SESSION['id'];
			$FirstName = $_SESSION['firstname'];
			$LastName = $_SESSION['lastname'];
			$UserName = $_SESSION['username'];
			$Email = $_SESSION['email'];
			$Title = $_SESSION['title'];
			$Course = $_SESSION['course'];
			$Avatar = $_SESSION['avatar'];
		
				
		
					echo "<div style='margin: 0px 0px 0px 0px;  width: 2100px;' >";
											
						echo "<button name='left' type='button' class='container' style=' background-color: white; font-size: 1em; letter-spacing: .6em; float: left; border: 2px solid black;   text-indent: 2.0em; margin: 0px 0px 0px 0px; width: 22%;'>";
						if($Title == "admin")
						{
							echo "<a href='Admin.php' style='text-decoration: none;'>Admin Setting</a> "; 	
						}							
						echo "</button>";
										
						
						echo "<div name='right' class='container' style=' font-size: 1em; letter-spacing: .6em; float: left; border: 2px solid black;   text-indent: 2.0em;  margin: 0px 0px 0px 456px; width: 22%;'>";
							echo "First Name: "; 
							echo $_SESSION['firstname'];
						echo "</div>";
						
						
						echo "<button name='left' type='button' class='container' style=' background-color: white; font-size: 1em; letter-spacing: .6em; float: left; border: 2px solid black;   text-indent: 2.0em;  margin: 10px 357px 0px 0px; width: 22%;'>";
							echo "<a href='home.php' style='text-decoration: none;'>Home Page</a>"; 
							
						echo "</button>";
						
		
						echo "<div name='right' class='container' style='font-size: 1em; letter-spacing: .6em; float: left; border: 2px solid black;   text-indent: 2.0em; margin: 10px 0px 0px 100px; width: 22%;'>";
							echo "Last Name: "; 
							echo $LastName;
						echo "</div>";
						
						
						echo "<button name='left' type='button' class='container' style='background-color: white; text-decoration: none; font-size: 1em; letter-spacing: .6em; float: left; border: 2px solid black;   text-indent: .2em;  margin: 10px 357px 0px 0px; width: 22%;'>";
							echo "<a href='StudySettingPage.php' style='text-decoration: none;'>Study Settings Page</a>"; 
							
						echo "</button>";
						
		
		
						echo "<div name='right' class='container' style='font-size: 1em; letter-spacing: .6em; float: left; border: 2px solid black;   text-indent: 2.0em; margin: 10px 0px 0px 100px; width: 22%;'>";
							echo "Username: "; 
							echo $UserName;
						echo "</div>";
						
						
						
						
						
						
						
						
						
						
						
					
							
							
						echo "<div class='container' style='font-size: 1em; letter-spacing: .6em; float: left; border: 2px solid black;   text-indent: 2.0em; margin: 10px 0px 0px 917.8px; width: 32%;'>";
							echo "Email: "; 
							echo $Email;
						echo "</div>";
						
						
						echo "<div class='container' style='font-size: 1em; letter-spacing: .6em; float: left; border: 2px solid black;   text-indent: 2.0em; margin: 10px 0px 0px 917.8px; width: 32%;'>";
							echo "Title: "; 
							echo $Title;
						echo "</div>";
						
						
						echo "<div class='container' style='font-size: 1em; letter-spacing: .6em; float: left; border: 2px solid black;   text-indent: 2.0em; margin: 10px 0px 0px 917.8px; width: 32%;'>";
							echo "Course: "; 
							echo $Course;
						echo "</div>";
							
						echo "</div>";
					echo "</div>";   
				 				 
			?>	
		</div>		
	</body>	
</html>

