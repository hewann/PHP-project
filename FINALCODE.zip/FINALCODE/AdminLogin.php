<!DOCTYPE html>
<html>
<head>
<!--Author: Saud Alanazi-->
<!--The purpose of this page is to Allow the Admin to Login-->
<!--///////////////////////////////////////
//				TEAM 1					 //
////////////////////////////////////////-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="Demo.css">
</head>
	<body>
	<div  class=" w3-top w-left">
		<img src="Hiwot_Gezahegn_light.png" alt="Avatar" style="max-width:120px;">
	</div>
	<!-- Usage of Header File to print at the top of website-->
	<?php
		require('Header.php');
	?>
	<div class=" w3-margin-top w3-center">
	<!-- Display the Contents for Logging in -->
		<h2 style="font-size: 2em; letter-spacing: 1em; background-color: white;">Admin Login Panel</h2>
	</div>

<div id="id01" class="modal">
	<form class="modal-content animate" action="loginVerification.php" method="post">
		<div class="imgcontainer">
			<span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
			<img src="Slack_project_icon.png" alt="Avatar" class="avatar">
		</div>
		<div class="container">
			<label for="uname"><b>Enter User Name</b></label>
			<br>
			<input type="text" placeholder="Enter Username" name="uname" required>
			<br>
			  
			<label for="psw"><b>Enter Password</b></label>
			<br>
			<input type="password" placeholder="Enter Password" name="psw" required>
			<br>
				
			<button type="submit">Verify Login</button>
			<label>
				<input type="checkbox" checked="checked" name="remember"> Remember me
			</label>
		</div>

		<div class="container" style="background-color:#f1f1f1">
			<button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
			<span class="psw">Forgot <a href="ResetPassword.php">password?</a></span>
		</div>
	</form>
</div>		
		<br>	<br>	<br>	<br>	<br>	<br>	<br>	<br>
		<!-- Header -->
		<header class="w3-display-container w3-content w3-wide" style="max-width:1500px;" id="home">
		  <div class="w3-display-middle w3-margin-top w3-center">
			<h1 class="w3-xxlarge w3-text-white">
			<span class="w3-padding w3-black w3-opacity-min">
			<b><button onclick="document.getElementById('id01').style.display='block'"class="w3-button">Welcome</button></b>
			</span> 	
			</h1>	
		  </div>
		</header>
		<br>	<br>	<br>	<br>
			<p class="w3-center"> <img src="groupfooterfinal.png"></p>
		<?php
			// starting the session
			session_start(); 	
		?>
	</body>

</html>
