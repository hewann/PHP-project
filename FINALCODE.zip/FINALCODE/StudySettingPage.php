<!DOCTYPE html>
<html>
<head>
		<!-- Page Created by:  Christian Mundell
		<!--///////////////////////////////////////
		//				TEAM 1					 //
		////////////////////////////////////////-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="Demo.css">
</head>
	<body>
		<div  class=" w3-top w-left">
			<img src="Black_Light.png" alt="Avatar"  style="max-width:70px;">	
		</div>
		<?php
			require('Header.php');
		?>
		<div class=" w3-margin-top w3-center">
			<h2 style="font-size: 2em; letter-spacing: 1em; background-color: white;"> STUDY SETTING PAGE</h2>
		</div>	
		<br>	<br>	<br> 

			<h1 class="w3-xlarge w3-text-white">		
				<form action="FlashSession.php" method="post">
					<table border="0"align="center" style="margin: 0px auto;" >
						<tr class=" w3-black w3-opacity-min w3-center">	
							<td>
								<br>Topic</br>
								<select name="topic">
									<option value="a">Math</option>
									<option value="b">Science</option>
									<option value="c">History</option>
								</select>
							</td>	
							<td>
								<br>Question Difficulty</br>
								<select name="que_dif">
									<option value="a">Easy</option>
									<option value="b">Medium</option>
									<option value="c">Hard</option>
									<option value="d">Very Hard</option>
									<option value="e">Let get serious</option>
									<option value="f">Get ready to be wrong.... a lot</option>
									<option value="g">Professional</option>
									<option value="h">Prove you're stupid mode</option>
								</select>
							</td>	
							 <td>
								<button type="submit" name="Submit" value="Start Studying"> Start Studying
							</td>
						</tr>
					</table>  	
				</form>
			</h1>
	
		
		<?php
			// starting the session
			session_start(); 	
			$Id = $_SESSION['id'];
			$conn = new mysqli("localhost", "root", "TheMango0*", "betacode_database");
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			} 
			//Select a row with a question and answer
				$query = "	SELECT username, id
							FROM users 
							WHERE id = $Id";
				$result = $conn->query($query);
				if ($result->num_rows > 0) 
				{
					$row = $result->fetch_assoc();	
				}
				else 
				{
					echo"Could not obtain user info";
				}
			echo "ID: ";
			echo $row["id"];
			echo "<br>";
			echo "Username: ";
			echo $row["username"];
		?>
		<p class="w3-center"> <img src="groupfooterfinal.png"></p>
	</body>
</html>
