<html>
		<!--    
		Page Created by:  Abnezer Tefera 
		<!--///////////////////////////////////////
		//				TEAM 1					 //
		////////////////////////////////////////-->	
	<body>
	<!-- Login Model-->
		<div class=" w3-margin-top w3-center">				
			<h1 style="font-size: 2em; letter-spacing: 1em; background-color: white;">YOUSHOULDSTUDY.COM</h1>
		</div>				
		<div class="container" id="top" style="background-color: red;">
			<div class="w3-bar  w3-red w3-opacity-min w3-wide  w3-card-2">
				<a href="home.php" class="w3-bar-item w3-button  w3-text-white">Home</a>
				<a href="CreateAccount.php" class="w3-bar-item w3-button  w3-text-white"> Create an Account</a>
				<a href="LoginPage.php" class="w3-bar-item w3-button  w3-text-white"> Login</a>
				
			</div>
		</div>
	</body>
</html>