<html>
<head>
		<!-- Page Created by:  Christian Mundell
		<!--///////////////////////////////////////
		//				TEAM 1					 //
		////////////////////////////////////////-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="Demo.css">
</head>
	<body>	
		<div  class=" w3-top w-left">
			<img src="Black_Light.png" alt="Avatar"  style="max-width:70px;">	
		</div>
		<div class=" w3-margin-top w3-center">				
			<h1 style="font-size: 2em; letter-spacing: 1em; background-color: white;">YOUSHOULDSTUDY.COM</h1>
		</div>				
		<div class="container" id="top" style="background-color: red;">
			<div class="w3-bar  w3-red w3-opacity-min w3-wide  w3-card-2">
				
			</div>
		</div>
		<div class=" w3-margin-top w3-center">
			<h2 style="font-size: 2em; letter-spacing: 1em; background-color: white;">START FLASH SESSION PAGE</h2>
		</div>
		
		
		<br>	<br>	<br>	<br>
		<div class=" w3-center">
			<h1>Please wait to be redirected to the appropriate page</h1>
		</div>
		<?php
			// starting the session
			session_start();  
				
			$direction = "StudySettingPage.php";
			

			if (isset($_POST['Submit']))
			{ 
				$direction = "FlashCardSessionPage.php";
				$_SESSION['topic'] = $_POST['topic'];
				$_SESSION['que_dif'] = $_POST['que_dif'];
			} 

		 ?> 	
		<meta http-equiv="Refresh" content="5;url=<?php echo $direction; ?>">
		<p class="w3-center"> <img src="groupfooterfinal.png"></p>
	</body>
</html>