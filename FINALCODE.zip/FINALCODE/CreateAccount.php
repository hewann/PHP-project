<html>
	<head>
		<!--    Page Created by:  Abnezer Tefera 
		<!--///////////////////////////////////////
		//				TEAM 1					 //
		////////////////////////////////////////-->	
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="Demo.css">
	</head>
	<body>
		<!-- Login Model-->
		<div  class=" w3-top w-left">
			<img src="Abnezer_Tefera_light.png" alt="Avatar"  style="max-width:120px;">	
		</div>
		<?php
			require('Header.php');
		?>
		<div class=" w3-margin-top w3-center">
			<h2 style="font-size: 2em; letter-spacing: 1em; background-color: white;">CREATE ACCOUNT PAGE</h2>
		</div>
		
		<h1 class="w3-xlarge w3-text-white">		
			<form action="CreateAccount.php" method="post">
				<table border="0"  >
					<tr>	
						<td>
							<input type="text" placeholder="Enter First Name" name="firstname">
						</td>	
					</tr>
					<tr>	
						<td>
							<input type="text" placeholder="Enter Last Name" name="lastname">
						</td>	
					</tr>
					<tr>	
						<td>
							<input type="text" placeholder="Enter User Name" name="username">
						</td>	
					</tr>
					<tr>	
						<td>
							<input type="text" placeholder="Enter Password" name="password">
						</td>	
					</tr>
					<tr>	
						<td>
							<input type="text" placeholder="Enter Email" name="email">
						</td>	
					</tr>
					<tr>	
						<td>
							<br>Are you a student or teacher?</br>
							<select name="title">
							<option value="Student">Student</option>
							<option value="Teacher">Teacher</option>
							</select>
						</td>
					</tr>
					<tr>	
						<td>
							<br>What subject are you teaching?</br>
							<select name="course">
							<option value="Math">Math</option>
							<option value="Science">Science</option>
							<option value="History">History</option>
							</select>
						</td>
					</tr>
					<tr>	
						<td>
							<button type="submit" name="Submit" value="Start Studying"> Create Account
						</td>
					</tr>
				</table>  	
			</form>
		</h1>
		<p class="w3-center"> <img src="groupfooterfinal.png"></p>
		<?php		
			if(isset($_POST['Submit']))
			{
				// Define Variables
				$FirstName = $_POST['firstname'];
				$LastName = $_POST['lastname'];
				$UserName = $_POST['username'];
				$PassWord = $_POST['password'];
				$Email = $_POST['email'];
				$Title = $_POST['title'];
				$Course = $_POST['course'];
				// Establishing the connection
				$mysqli = new mysqli("localhost", "root", "TheMango0*", "betacode_database");	
				
				// Check connection
				if($mysqli === false){
					die("ERROR: Could not connect. " . $mysqli->connect_error);
				}
				 
				echo $Title;
				echo "print";	
				 
				// insert query into database table QATD
				$sql = "INSERT INTO users (firstname, lastname, username, password, email, 	title, admin, course, avatar) 
						VALUES ('$FirstName', '$LastName', '$UserName', '$PassWord', '$Email', '$Title', 0, '$Course', 'o')";
				if($mysqli->query($sql) === true){
					
				} 
				else{
					echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
				}
				 
				// Close connection
				$mysqli->close();
			}
		?>
	</body>
</html>