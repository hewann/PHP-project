<!DOCTYPE html>
<html>
	<head>
		<!--    Page Created by:  Abnezer Tefera 
		<!--///////////////////////////////////////
		//				TEAM 1					 //
		////////////////////////////////////////-->	
		   <title>YouShouldStudy.com - Home</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="Demo.css">
	</head>

	<body>
		<!-- Login Model-->
		<div  class=" w3-top w-left">	
			<img src="Abnezer_Tefera_light.png" alt="Avatar"  style="max-width:120px;">	
		</div>
		<?php
			require('Header.php');
		?>
		<div class=" w3-margin-top w3-center">
			<h2 style="font-size: 2em; letter-spacing: 1em; background-color: white;">HOME PAGE</h2>
		</div>	
		
		<?php

			$row;
			$graphicId;
		
				
			$conn = new mysqli("localhost", "root", "TheMango0*", "betacode_database");
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			} 
			
				//Get max number of rows
				$query = "SELECT id FROM graphics ";
				$result = $conn->query($query);
				
				//Randomly pick a question to display
				$graphicId = rand(1,$result->num_rows);
				
				//Select a row with a question and answer
				$query = "	SELECT filename, id
							FROM graphics 
							WHERE id = $graphicId";
				$result = $conn->query($query);
				
				
				
				if ($result->num_rows > 0) 
				{
					$row = $result->fetch_assoc();	
				}
				else 
				{
					echo"Error....";

				}
				
				
			
				$conn->close();	
				
			
				
				
			?>	
	
		
		<header class="w3-display-container w3-center w3-content w3-wide" style="max-width:1500px;" id="home">
			<img class="w3-image" src=<?php echo $row["filename"];?>  alt="Architecture" width="1300" height="500">
		</header>  
		
		<p class="w3-center"> <img src="groupfooterfinal.png"></p>
	</body>	
</html>