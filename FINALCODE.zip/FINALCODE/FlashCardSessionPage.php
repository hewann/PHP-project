<!DOCTYPE html>
<html>
<head>
		<!-- Page Created by:  Christian Mundell
		<!--///////////////////////////////////////
		//				TEAM 1					 //
		////////////////////////////////////////-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="Demo.css">
</head>
	<body>
		<div  class=" w3-top w-left">
			<img src="Black_Light.png" alt="Avatar"  style="max-width:70px;">	
		</div>
		<?php
			require('Header.php');
		?>
		<div class=" w3-margin-top w3-center">
			<h2 style="font-size: 2em; letter-spacing: 1em; background-color: white;">FLASH CARD SESSION PAGE</h2>
		</div>

		<?php
			session_start(); 

			//Testing search terms
			$topic = $_SESSION['topic'];
			$difficulty = $_SESSION['que_dif'];
			$testTable;
			$row;
			$questionId;
		
				
			$conn = new mysqli("localhost", "root", "TheMango0*", "betacode_database");

		
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			} 
			switch ($difficulty)
			{
				case "a": $testTable = "qa_easy"; break;
				case "b": $testTable = "qa_medium"; break;
				case "c": $testTable = "qa_hard"; break;
				default: $testTable = "qa_hard"; break;
			}
			switch($topic)
			{
				case "a": $testTable .= '_math'; break;
				case "b": $testTable .= '_science'; break;
				case "c": $testTable .= '_history'; break;
			}
		
				
				
				//Get max number of rows
				$query = "	SELECT id FROM $testTable ";
				$result = $conn->query($query);
				
				//Randomly pick a question to display
				$questionId = rand(1,$result->num_rows);
				
				//Select a row with a question and answer
				$query = "	SELECT question, answer, id
							FROM $testTable 
							WHERE id = $questionId";
				$result = $conn->query($query);
				
				
				
				if ($result->num_rows > 0) 
				{
					$row = $result->fetch_assoc();	
				}
				else 
				{
					echo"Error....";

				}
				
				
			
				$conn->close();	
			?>	
			
			<!-- Question and Answer -->
		<div class="w3-margin-top w3-center">
				<h1 class="w3-xlarge w3-text-white">		  
					<table border="0"align="center" style="margin: 0px auto;">
						<tr class=" w3-black w3-opacity-min w3-center">	
							<td>
								<h1><br>QUESTION</br></h1>
								<!--Display Question Via php-->
								<?php 
								echo $row["question"];
								?>
							</td>	
						</tr>
						<tr class=" w3-black w3-opacity-min w3-center">	
							<td>
								<h1><br>ANWSER</br></h1>
								<!--Display Answer Via php-->
								<?php 
								echo $row["answer"];							
								?>
							</td>	
						</tr>
					</table>  	
				</h1>
		</div>
		
		<meta http-equiv="refresh" content="10">	
		<p class="w3-center"> <img src="groupfooterfinal.png"></p>
	</body>
</html>