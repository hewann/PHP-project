<!DOCTYPE html>
<html>
	<head>
	<!--Page was created by Hiwot_Gezahegn-->
	<!--///////////////////////////////////////
	//				TEAM 1					 //
	////////////////////////////////////////-->
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="Demo.css">

	<title> Forgot </title>		
	</head>
	
	
	
<body  style="background-color:#f0f0f0;">
	
	<div  class=" w3-top w-left">
		<img src="Hiwot_Gezahegn_light.png" alt="Avatar" style="max-width:120px;">			
	</div>	
	<?php
		require('Header.php');
	?>
	<div class=" w3-margin-top w3-center">
		<h2 style="font-size: 2em; letter-spacing: 1em; background-color: white;">RESET PASSWORD PAGE</h2>
	</div>
		
	<div class="header">
		<h2> Forgot your password </h2>  
	</div>
	<form method="post" action="ResetPassword.php">	 
		<div class="info">
			<label> Enter your email</label>
			<input type="text" placeholder="" name="email" required>
		</div>	 
		<div class="info">
			<label> Enter your new password</label>
			<input type="password" placeholder="" name="password" required><br>
			<button type="submit" name= "enter" class="btn"> Change</button>
		</div>	 
	</form>
 		
	<?php	

		//if form data enter has a value set
		if (isset($_POST['enter']))
		{ 

			//connecect to the data base
			$connection = new mysqli('localhost', 'root', 'TheMango0*', 'betacode_database');

			//set the variable $email to the form data where the user to input
			$email = mysqli_real_escape_string($connection,$_POST['email']);
		 
			// check if the entered email is on the db
			$query = mysqli_query($connection, "SELECT * FROM users 
			WHERE email = '$email'");
			
			// if on the db 
			if ($query==true){
				$newpassword = mysqli_real_escape_string($connection,$_POST['password']);
		 
				$Changequery = mysqli_query($connection,"UPDATE users SET password = '$newpassword' 
				WHERE email = '$email'");
		 
				if ($Changequery==true){
		 
				echo "<div class='header'>
				<h3>Password update successful!</h3><br/>
				Click here to <a href='updatePassword.php'>login</a>  
				</div>";
				}
				else {
					echo "<div class='header'>
					<h3>Something went wrong!</h3><br/>
					Plase enter <a href='updatePassword.php'>it again</a>  
					</div>";
		 
				}
			}
		 
			else {
		 
				echo "<div class='header'>
				<h3>The entered email is not on the database!</h3><br/>
				Click here to enter <a href='updatePassword.php'>it again</a>  
				</div>";
		 
			}		 
		}
	?>

	<br>	<br>	<br>	<br>
			<p class="w3-center"> <img src="groupfooterfinal.png"></p>

</body>
</head>